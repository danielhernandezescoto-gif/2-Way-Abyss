    let state = { selectedId: 'Chamelecon_SPS', layer: 'def', hMode: 'vh', lang: 'es', theme: 'blue', sim: 'live', timeIdx: 5, showSatLabels: true };
    let playTimer = null;

    const I18N = {
      es: {
        badge: 'RED NACIONAL · COPECO / SINAGER',
        sub: 'Monitoreo satelital de 9 zonas críticas en Honduras (Sentinel-1 + Sentinel-2 + Open-Meteo + NISAR)',
        btnPdf: 'Generar Informe Nacional',
        kpi1Lbl: 'Cobertura Nacional', kpi1Val: '9 Zonas Críticas',
        kpi2Lbl: 'Zona Seleccionada',
        kpi3Lbl: 'Lectura Actual',
        kpi4Lbl: 'Decisión (+6 días)',
        sec1: '1. Zonas Críticas de Honduras', btnCountry: 'Ver país completo',
        mapTitle: 'Mapa Nacional · Solo Honduras (Cuencas, Bordos y Laderas)',
        lDef: 'Deformación (mm)', lWater: 'Agua Radar (dB)', lNdwi: 'Cámara Óptica (NDWI)',
        lblSatData: 'Datos en mapa',
        btnEvoPlay: '▶ Ver Evolución', btnEvoStop: '⏸ Pausar',
        nisarPasses: 'Pases NISAR cada 12 días (Sep – Nov 2026)',
        legSafe: 'Seguro (<35%)', legWarn: 'Precaución (35–64%)', legCrit: 'Crítico (≥65%)',
        sec2: '2. Pronóstico Cada 6 Días (NISAR + Open-Meteo + SMAP)',
        sec3: '3. Evolución y Validación del Modelo en la Zona',
        sec4: '4. Evolución Histórica Real de 2 Años (Nov 2024 – Nov 2026)',
        sec4Sub: 'Promedios mensuales reales extraídos de Google Earth Engine (25 meses)',
        cloudy: 'Nublado'
      },
      en: {
        badge: 'NATIONAL NETWORK · COPECO / SINAGER',
        sub: 'Satellite monitoring of 9 critical zones in Honduras (Sentinel-1 + Sentinel-2 + Open-Meteo + NISAR)',
        btnPdf: 'Generate National Report',
        kpi1Lbl: 'National Coverage', kpi1Val: '9 Critical Zones',
        kpi2Lbl: 'Selected Zone',
        kpi3Lbl: 'Current Reading',
        kpi4Lbl: 'Decision (+6 days)',
        sec1: '1. Critical Zones in Honduras', btnCountry: 'Full country view',
        mapTitle: 'National Map · Honduras Only (Basins, Levees & Slopes)',
        lDef: 'Deformation (mm)', lWater: 'Radar Water (dB)', lNdwi: 'Optical Camera (NDWI)',
        lblSatData: 'Map data labels',
        btnEvoPlay: '▶ Play Evolution', btnEvoStop: '⏸ Pause',
        nisarPasses: 'NISAR passes every 12 days (Sep – Nov 2026)',
        legSafe: 'Safe (<35%)', legWarn: 'Caution (35–64%)', legCrit: 'Critical (≥65%)',
        sec2: '2. 6-Day Forecast (NISAR + Open-Meteo + SMAP)',
        sec3: '3. Zone Model Evolution & Validation',
        sec4: '4. Real 2-Year Historical Evolution (Nov 2024 – Nov 2026)',
        sec4Sub: 'Real monthly averages extracted from Google Earth Engine (25 months)',
        cloudy: 'Cloudy'
      }
    };

    function getZoneMetricsAtTime(z, tIdx) {
      const gee = REAL_2Y_GEE[z.id];
      const def = z.defSeries[tIdx];
      // Indices 22 (2026-09), 23 (2026-10), 24 (2026-11)
      const geeIdx = 22 + Math.floor(tIdx / 2);
      const vh = gee.vh[geeIdx] !== null ? gee.vh[geeIdx] : gee.vh_last;
      // Use exact monthly NDWI when available, otherwise fallback to latest valid NDWI for risk continuity while displaying real status
      const ndwiRaw = gee.ndwi[geeIdx];
      const ndwiForRisk = ndwiRaw !== null ? ndwiRaw : gee.ndwi_last;
      return { def, vh, ndwiRaw, ndwiForRisk, gee };
    }

    function computeCompositeRisk(m) {
      // 1. NISAR Deformation (50% weight, 0..24 mm)
      const defScore = Math.min(50, Math.max(0, (m.def / 24) * 50));
      // 2. Sentinel-1 VH Backscatter (30% weight, -11.5 dB dry to -18.0 dB saturated/water)
      const vhScore = Math.min(30, Math.max(0, ((-m.vh - 11.5) / 6.5) * 30));
      // 3. Sentinel-2 NDWI (20% weight, -0.65 dry to +0.20 water surface)
      const ndwiScore = m.ndwiForRisk !== null
        ? Math.min(20, Math.max(0, ((m.ndwiForRisk + 0.65) / 0.85) * 20))
        : (vhScore / 30) * 20;
      return Math.round(defScore + vhScore + ndwiScore);
    }

    function getRiskBadge(score) {
      if (score >= 65) return { label: state.lang === 'es' ? 'CRÍTICO' : 'CRITICAL', cls: 'bg-rose-500/20 text-rose-300 border-rose-500/40', textCls: 'text-rose-400', hex: '#f43f5e' };
      if (score >= 35) return { label: state.lang === 'es' ? 'PRECAUCIÓN' : 'CAUTION', cls: 'bg-amber-500/20 text-amber-300 border-amber-500/40', textCls: 'text-amber-400', hex: '#f59e0b' };
      return { label: state.lang === 'es' ? 'SEGURO' : 'SAFE', cls: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', textCls: 'text-emerald-400', hex: '#10b981' };
    }

    // Strict Honduras bounding box + dark mask outside Honduras
    const HONDURAS_BOUNDS = L.latLngBounds(
      L.latLng(12.85, -89.45), // Southwest Honduras
      L.latLng(16.65, -83.05)  // Northeast Honduras (including Gracias a Dios / Islas de la Bahia)
    );

    const map = L.map('map', {
      center: [14.78, -86.65],
      zoom: 7,
      minZoom: 7,
      maxZoom: 17,
      maxBounds: HONDURAS_BOUNDS,
      maxBoundsViscosity: 1.0
    });

    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: 'Tiles © Esri · Honduras Territory',
      bounds: HONDURAS_BOUNDS
    }).addTo(map);

    // Subtle Honduras territory frame rectangle
    L.rectangle(HONDURAS_BOUNDS, {
      color: '#38bdf8',
      weight: 1.5,
      dashArray: '6, 6',
      fill: false,
      interactive: false
    }).addTo(map);

    const layerGroup = L.layerGroup().addTo(map);

    const zoneChart = new Chart(document.getElementById('zoneChart'), {
      type: 'line',
      data: {
        labels: ['15 sep', '27 sep', '9 oct', '21 oct', '2 nov', '14 nov'],
        datasets: [
          { label: 'Deformación Observada (mm)', data: [], borderColor: '#38bdf8', backgroundColor: 'rgba(56,189,248,0.18)', fill: true, tension: 0.35 },
          { label: 'Umbral Crítico (18 mm)', data: [18, 18, 18, 18, 18, 18], borderColor: '#f43f5e', borderDash: [5, 5], pointRadius: 0, fill: false }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false, scales: { x: { ticks: { color: '#94a3b8' } }, y: { ticks: { color: '#94a3b8' } } }, plugins: { legend: { labels: { color: '#cbd5e1' } } } }
    });

    const history2yChart = new Chart(document.getElementById('history2yChart'), {
      type: 'line',
      data: {
        labels: REAL_2Y_GEE['Chamelecon_SPS'].months,
        datasets: [{ label: 'Sentinel-1 VH (dB)', data: [], borderColor: '#22d3ee', backgroundColor: 'rgba(34,211,238,0.15)', fill: true, tension: 0.25, spanGaps: true }]
      },
      options: { responsive: true, maintainAspectRatio: false, scales: { x: { ticks: { color: '#94a3b8' } }, y: { ticks: { color: '#94a3b8' } } }, plugins: { legend: { labels: { color: '#cbd5e1' } } } }
    });

    function applyTranslations() {
      const t = I18N[state.lang];
      document.getElementById('hdr-badge').textContent = t.badge;
      document.getElementById('hdr-sub').textContent = t.sub;
      document.getElementById('btn-pdf').textContent = t.btnPdf;
      document.getElementById('kpi1-lbl').textContent = t.kpi1Lbl;
      document.getElementById('kpi1-val').textContent = t.kpi1Val;
      document.getElementById('kpi2-lbl').textContent = t.kpi2Lbl;
      document.getElementById('kpi3-lbl').textContent = t.kpi3Lbl;
      document.getElementById('kpi4-lbl').textContent = t.kpi4Lbl;
      document.getElementById('sec1-title').textContent = t.sec1;
      document.getElementById('btn-country').textContent = t.btnCountry;
      document.getElementById('map-title').textContent = t.mapTitle;
      document.querySelector('[data-layer="def"]').textContent = t.lDef;
      document.querySelector('[data-layer="water"]').textContent = t.lWater;
      document.querySelector('[data-layer="ndwi"]').textContent = t.lNdwi;
      document.getElementById('lbl-sat-data').textContent = t.lblSatData;
      document.getElementById('btn-play-evo').textContent = playTimer ? t.btnEvoStop : t.btnEvoPlay;
      document.getElementById('nisar-passes-lbl').textContent = t.nisarPasses;
      document.getElementById('leg-safe').textContent = t.legSafe;
      document.getElementById('leg-warn').textContent = t.legWarn;
      document.getElementById('leg-crit').textContent = t.legCrit;
      document.getElementById('sec2-title').textContent = t.sec2;
      document.getElementById('sec3-title').textContent = t.sec3;
      document.getElementById('sec4-title').textContent = t.sec4;
      document.getElementById('sec4-sub').textContent = t.sec4Sub;
    }

    function renderAll() {
      applyTranslations();
      const t = I18N[state.lang];
      const dateStr = (state.lang === 'es' ? PASS_DATES_ES : PASS_DATES_EN)[state.timeIdx];
      document.getElementById('evo-date-badge').textContent = dateStr;

      const list = document.getElementById('sector-list');
      list.innerHTML = '';
      layerGroup.clearLayers();

      ZONES.forEach(z => {
        const m = getZoneMetricsAtTime(z, state.timeIdx);
        const risk = computeCompositeRisk(m);
        const badge = getRiskBadge(risk);
        const isSel = z.id === state.selectedId;
        const ndwiDisplay = m.ndwiRaw !== null ? m.ndwiRaw.toFixed(3) : `${t.cloudy} (${m.gee.ndwi_last.toFixed(2)})`;
        const metricText = state.layer === 'def' ? `${m.def.toFixed(1)} mm`
          : state.layer === 'water' ? `${m.vh.toFixed(2)} dB`
          : ndwiDisplay;

        const btn = document.createElement('button');
        btn.className = `w-full text-left p-3 rounded-xl border transition flex items-center justify-between ${isSel ? 'bg-cyan-950/50 border-cyan-400/60' : 'bg-slate-950/60 border-slate-800 hover:border-slate-600'}`;
        btn.innerHTML = `
          <div>
            <p class="text-sm font-bold text-white">${z.name}</p>
            <p class="text-xs text-slate-400">${z.dept} · ${z.pts} pts</p>
          </div>
          <div class="text-right">
            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full border ${badge.cls}">${badge.label} · ${risk}%</span>
            <p class="text-xs font-bold mt-1" style="color:${badge.hex}">${metricText}</p>
          </div>`;
        btn.onclick = () => { state.selectedId = z.id; map.setView([z.lat, z.lon], 12); renderAll(); };
        list.appendChild(btn);

        // Circle + Data Overlay directly on Satellite Imagery
        const circleColor = state.layer === 'def' ? badge.hex : (state.layer === 'water' ? '#22d3ee' : '#3b82f6');
        const radiusScale = 3400 + (m.def * 85);
        const circle = L.circle([z.lat, z.lon], {
          radius: radiusScale,
          color: circleColor,
          fillColor: circleColor,
          fillOpacity: 0.34,
          weight: isSel ? 3 : 2
        }).bindPopup(`
          <div style="font-family:Inter,sans-serif;min-width:190px;">
            <b>${z.name}</b> (${z.dept})<br/>
            <span style="color:#0284c7;font-weight:700;">${dateStr} · Riesgo ${risk}%</span><hr style="margin:4px 0;"/>
            • NISAR Def: <b>${m.def.toFixed(1)} mm</b><br/>
            • Sentinel-1 VH: <b>${m.vh.toFixed(2)} dB</b><br/>
            • Sentinel-2 NDWI: <b>${ndwiDisplay}</b>
          </div>
        `).addTo(layerGroup);

        if (state.showSatLabels) {
          const shortVal = state.layer === 'def'
            ? `${m.def.toFixed(1)} mm · ${risk}%`
            : state.layer === 'water'
              ? `${m.vh.toFixed(1)} dB`
              : (m.ndwiRaw !== null ? `NDWI ${m.ndwiRaw.toFixed(2)}` : `NDWI ${m.gee.ndwi_last.toFixed(2)}*`);
          circle.bindTooltip(`${z.name.split(' ')[0]}: ${shortVal}`, {
            permanent: true,
            direction: 'top',
            offset: [0, -6],
            className: 'sat-badge-tooltip'
          });
        }
      });

      const cur = ZONES.find(z => z.id === state.selectedId);
      const curM = getZoneMetricsAtTime(cur, state.timeIdx);
      const curRisk = computeCompositeRisk(curM);
      const curBadge = getRiskBadge(curRisk);
      const curNdwiTxt = curM.ndwiRaw !== null ? curM.ndwiRaw.toFixed(3) : `${t.cloudy} (${curM.gee.ndwi_last.toFixed(3)})`;

      document.getElementById('kpi2-val').textContent = cur.name;
      document.getElementById('kpi2-sub').textContent = `${cur.dept} · ${cur.pts} pts`;
      document.getElementById('kpi3-lbl').textContent = `${t.kpi3Lbl} (${dateStr})`;
      document.getElementById('kpi3-val').className = `text-xl font-bold mt-1 ${curBadge.textCls}`;
      document.getElementById('kpi3-val').textContent = `${curM.def.toFixed(1)} mm · ${state.lang === 'es' ? 'Riesgo' : 'Risk'} ${curRisk}%`;
      document.getElementById('kpi3-sub').textContent = `VH: ${curM.vh.toFixed(2)} dB · NDWI: ${curNdwiTxt}`;
      document.getElementById('kpi4-val').className = `text-xl font-bold mt-1 ${curBadge.textCls}`;
      document.getElementById('kpi4-val').textContent = curBadge.label;

      // Forecast cards
      const mult = state.sim === 'live' ? 1 : (state.sim === 'light' ? 1.3 : (state.sim === 'mod' ? 2.2 : 3.6));
      const fcDiv = document.getElementById('forecast-cards');
      fcDiv.innerHTML = '';
      ['+6d (20 nov)', '+12d (26 nov)', '+18d (2 dic)', '+24d (8 dic)'].forEach((lbl, idx) => {
        const rain = Math.round(cur.rain6d[idx] * mult);
        const projDef = (curM.def + (idx + 1) * (rain > 60 ? 1.4 : 0.45)).toFixed(1);
        fcDiv.innerHTML += `
          <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
            <p class="text-[11px] text-slate-400 font-semibold">${lbl}</p>
            <p class="text-base font-bold text-cyan-400 mt-1">${rain} mm</p>
            <p class="text-xs text-slate-300 mt-0.5">Proy: ${projDef} mm</p>
          </div>`;
      });

      // Zone recent evolution chart
      const gee = REAL_2Y_GEE[cur.id];
      if (state.layer === 'def') {
        zoneChart.data.datasets[0].label = state.lang === 'es' ? 'Deformación NISAR (mm)' : 'NISAR Deformation (mm)';
        zoneChart.data.datasets[0].data = cur.defSeries;
        zoneChart.data.datasets[1].hidden = false;
      } else if (state.layer === 'water') {
        zoneChart.data.datasets[0].label = 'Sentinel-1 VH (dB)';
        const v9 = gee.vh[22], v10 = gee.vh[23], v11 = gee.vh[24] ?? gee.vh_last;
        zoneChart.data.datasets[0].data = [v9, v9, v10, v10, v11, v11];
        zoneChart.data.datasets[1].hidden = true;
      } else {
        zoneChart.data.datasets[0].label = 'Sentinel-2 NDWI';
        const n9 = gee.ndwi[22] ?? gee.ndwi_last, n10 = gee.ndwi[23] ?? gee.ndwi_last, n11 = gee.ndwi[24] ?? gee.ndwi_last;
        zoneChart.data.datasets[0].data = [n9, n9, n10, n10, n11, n11];
        zoneChart.data.datasets[1].hidden = true;
      }
      zoneChart.update();

      // 2-Year Real GEE Chart
      history2yChart.data.labels = gee.months;
      history2yChart.data.datasets[0].label = state.hMode === 'vh'
        ? `Sentinel-1 VH (dB) — ${cur.name}`
        : `Sentinel-2 NDWI — ${cur.name}`;
      history2yChart.data.datasets[0].borderColor = state.hMode === 'vh' ? '#22d3ee' : '#34d399';
      history2yChart.data.datasets[0].backgroundColor = state.hMode === 'vh' ? 'rgba(34,211,238,0.15)' : 'rgba(52,211,153,0.15)';
      history2yChart.data.datasets[0].data = state.hMode === 'vh' ? gee.vh : gee.ndwi;
      history2yChart.update();
    }

    // Evolution slider & play button
    const evoSlider = document.getElementById('evo-slider');
    evoSlider.oninput = e => {
      state.timeIdx = parseInt(e.target.value, 10);
      renderAll();
    };

    document.getElementById('btn-play-evo').onclick = () => {
      if (playTimer) {
        clearInterval(playTimer);
        playTimer = null;
        renderAll();
      } else {
        if (state.timeIdx >= 5) state.timeIdx = 0;
        evoSlider.value = state.timeIdx;
        renderAll();
        playTimer = setInterval(() => {
          state.timeIdx = (state.timeIdx + 1) % 6;
          evoSlider.value = state.timeIdx;
          renderAll();
          if (state.timeIdx === 5) {
            clearInterval(playTimer);
            playTimer = null;
            renderAll();
          }
        }, 1100);
      }
    };

    document.getElementById('chk-sat-labels').onchange = e => {
      state.showSatLabels = e.target.checked;
      renderAll();
    };

    document.querySelectorAll('.theme-btn').forEach(b => b.onclick = () => {
      state.theme = b.dataset.theme;
      document.body.classList.remove('theme-dark', 'theme-light');
      if (state.theme === 'dark') document.body.classList.add('theme-dark');
      if (state.theme === 'light') document.body.classList.add('theme-light');
      document.querySelectorAll('.theme-btn').forEach(x => x.className = `theme-btn px-2.5 py-1 rounded-md font-semibold ${x.dataset.theme === state.theme ? 'bg-cyan-600 text-white' : 'text-slate-400'}`);
      const tickColor = state.theme === 'light' ? '#334155' : '#94a3b8';
      const legendColor = state.theme === 'light' ? '#0f172a' : '#cbd5e1';
      [zoneChart, history2yChart].forEach(ch => {
        ch.options.scales.x.ticks.color = tickColor;
        ch.options.scales.y.ticks.color = tickColor;
        ch.options.plugins.legend.labels.color = legendColor;
        ch.update();
      });
    });

    document.querySelectorAll('.lang-btn').forEach(b => b.onclick = () => {
      state.lang = b.dataset.lang;
      document.querySelectorAll('.lang-btn').forEach(x => x.className = `lang-btn px-2.5 py-1 rounded-md font-semibold ${x.dataset.lang === state.lang ? 'bg-cyan-600 text-white' : 'text-slate-400'}`);
      renderAll();
    });

    document.querySelectorAll('.layer-btn').forEach(b => b.onclick = () => {
      state.layer = b.dataset.layer;
      document.querySelectorAll('.layer-btn').forEach(x => x.className = `layer-btn px-2.5 py-1 rounded-lg font-semibold ${x.dataset.layer === state.layer ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-300'}`);
      renderAll();
    });

    document.querySelectorAll('.h2y-btn').forEach(b => b.onclick = () => {
      state.hMode = b.dataset.hmode;
      document.querySelectorAll('.h2y-btn').forEach(x => x.className = `h2y-btn px-3 py-1 rounded-lg font-semibold ${x.dataset.hmode === state.hMode ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-300'}`);
      renderAll();
    });

    document.getElementById('rain-sim').onchange = e => { state.sim = e.target.value; renderAll(); };
    document.getElementById('btn-country').onclick = () => map.fitBounds(HONDURAS_BOUNDS);

    document.getElementById('btn-pdf').onclick = () => {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'letter' });
      const isEs = state.lang === 'es';
      const dateStr = (isEs ? PASS_DATES_ES : PASS_DATES_EN)[state.timeIdx];

      // Page 1 Header Banner
      doc.setFillColor(6, 13, 31);
      doc.rect(0, 0, 279.4, 24, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(isEs ? 'ABYSS HONDURAS — INFORME EJECUTIVO NACIONAL DE RIESGO (COPECO / SINAGER)' : 'ABYSS HONDURAS — NATIONAL EXECUTIVE RISK REPORT (COPECO / SINAGER)', 14, 11);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(125, 211, 252);
      doc.text(isEs
        ? `Emisión: 15 nov 2026 | Corte analizado: ${dateStr} | Fusión: NISAR (50%) + Sentinel-1 VH (30%) + Sentinel-2 NDWI (20%) + Open-Meteo`
        : `Issued: Nov 15, 2026 | Analyzed Pass: ${dateStr} | Fusion: NISAR (50%) + Sentinel-1 VH (30%) + Sentinel-2 NDWI (20%) + Open-Meteo`, 14, 18);

      const rowsP1 = ZONES.map(z => {
        const m = getZoneMetricsAtTime(z, state.timeIdx);
        const r = computeCompositeRisk(m);
        const cls = r >= 65 ? (isEs ? 'CRÍTICO' : 'CRITICAL') : (r >= 35 ? (isEs ? 'PRECAUCIÓN' : 'CAUTION') : (isEs ? 'SEGURO' : 'SAFE'));
        const ndwiTxt = m.ndwiRaw !== null ? m.ndwiRaw.toFixed(3) : (isEs ? `Nublado (${m.gee.ndwi_last.toFixed(2)})` : `Cloudy (${m.gee.ndwi_last.toFixed(2)})`);
        const rain6d = z.rain6d[0];
        const proj6d = (m.def + (rain6d > 60 ? 1.4 : 0.45)).toFixed(1);
        const actionTxt = r >= 65
          ? (isEs ? 'Alerta Roja / Evacuación preventiva' : 'Red Alert / Preventive evacuation')
          : (r >= 35 ? (isEs ? 'Vigilancia de bordos y drenajes' : 'Levee & drainage monitoring') : (isEs ? 'Monitoreo rutinario' : 'Routine monitoring'));
        return [
          `${cls} (${r}%)`,
          z.name,
          z.dept,
          `${z.pts}`,
          `${m.def.toFixed(1)} mm`,
          `${m.vh.toFixed(2)} dB`,
          ndwiTxt,
          `${rain6d} mm -> ${proj6d} mm`,
          actionTxt
        ];
      });

      doc.autoTable({
        startY: 30,
        head: [[
          isEs ? 'Clasificación' : 'Status',
          isEs ? 'Zona Crítica' : 'Critical Zone',
          isEs ? 'Departamento' : 'Department',
          isEs ? 'Pts' : 'Pts',
          isEs ? 'Deformación' : 'Deformation',
          'Sentinel-1 VH',
          'Sentinel-2 NDWI',
          isEs ? 'Pronóstico +6d' : '+6d Forecast',
          isEs ? 'Acción Prioritaria COPECO' : 'COPECO Priority Action'
        ]],
        body: rowsP1,
        theme: 'grid',
        styles: { fontSize: 8.5, cellPadding: 2.8, textColor: [15, 23, 42] },
        headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold' },
        alternateRowStyles: { fillColor: [241, 245, 249] },
        didParseCell: function(data) {
          if (data.section === 'body' && data.column.index === 0) {
            const val = String(data.cell.raw);
            if (val.includes('CRÍTICO') || val.includes('CRITICAL')) {
              data.cell.styles.fillColor = [254, 226, 226];
              data.cell.styles.textColor = [185, 28, 28];
              data.cell.styles.fontStyle = 'bold';
            } else if (val.includes('PRECAUCIÓN') || val.includes('CAUTION')) {
              data.cell.styles.fillColor = [254, 243, 199];
              data.cell.styles.textColor = [180, 83, 9];
              data.cell.styles.fontStyle = 'bold';
            } else {
              data.cell.styles.fillColor = [209, 250, 229];
              data.cell.styles.textColor = [4, 120, 87];
              data.cell.styles.fontStyle = 'bold';
            }
          }
        }
      });

      // Page 2: 2-Year Historical GEE Summary Table
      doc.addPage();
      doc.setFillColor(6, 13, 31);
      doc.rect(0, 0, 279.4, 24, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text(isEs ? 'PÁGINA 2 — HISTORIAL SATELITAL REAL DE 2 AÑOS (NOV 2024 – NOV 2026)' : 'PAGE 2 — REAL 2-YEAR SATELLITE HISTORY (NOV 2024 – NOV 2026)', 14, 11);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(125, 211, 252);
      doc.text(isEs ? 'Promedios mensuales reales extraídos de Google Earth Engine (25 meses · COPERNICUS S1_GRD y S2_SR)' : 'Real monthly averages extracted from Google Earth Engine (25 months · COPERNICUS S1_GRD & S2_SR)', 14, 18);

      const rowsP2 = ZONES.map(z => {
        const g = REAL_2Y_GEE[z.id];
        return [
          z.name,
          z.dept,
          `${g.vh_avg} dB`,
          `${g.vh_min} dB`,
          `${g.vh_max} dB`,
          `${g.vh_last} dB`,
          g.ndwi_avg !== null ? g.ndwi_avg.toFixed(3) : 'N/D',
          g.ndwi_last !== null ? g.ndwi_last.toFixed(3) : 'N/D',
          `${g.s1_count}/25 m · ${g.s2_count}/25 m`
        ];
      });

      doc.autoTable({
        startY: 30,
        head: [[
          isEs ? 'Zona Monitoreada' : 'Monitored Zone',
          isEs ? 'Departamento' : 'Department',
          isEs ? 'VH Promedio (2a)' : 'VH Avg (2y)',
          isEs ? 'VH Mínimo' : 'VH Min',
          isEs ? 'VH Máximo' : 'VH Max',
          isEs ? 'Último VH' : 'Latest VH',
          isEs ? 'NDWI Promedio' : 'NDWI Avg',
          isEs ? 'Último NDWI' : 'Latest NDWI',
          isEs ? 'Cobertura S1 / S2' : 'S1 / S2 Coverage'
        ]],
        body: rowsP2,
        theme: 'grid',
        styles: { fontSize: 8.5, cellPadding: 2.8, textColor: [15, 23, 42] },
        headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold' },
        alternateRowStyles: { fillColor: [241, 245, 249] }
      });

      doc.save('Informe_Nacional_Abyss_Honduras.pdf');
    };

    renderAll();
    };

    document.getElementById('btn-play-evo').onclick = () => {
      if (playTimer) {
        clearInterval(playTimer);
        playTimer = null;
        renderAll();
      } else {
        if (state.timeIdx >= 5) state.timeIdx = 0;
        evoSlider.value = state.timeIdx;
        renderAll();
        playTimer = setInterval(() => {
          state.timeIdx = (state.timeIdx + 1) % 6;
          evoSlider.value = state.timeIdx;
          renderAll();
          if (state.timeIdx === 5) {
            clearInterval(playTimer);
            playTimer = null;
            renderAll();
          }
        }, 1100);
      }
    };

    document.getElementById('chk-sat-labels').onchange = e => {
      state.showSatLabels = e.target.checked;
      renderAll();
    };

    document.querySelectorAll('.theme-btn').forEach(b => b.onclick = () => {
      state.theme = b.dataset.theme;
      document.body.classList.remove('theme-dark', 'theme-light');
      if (state.theme === 'dark') document.body.classList.add('theme-dark');
      if (state.theme === 'light') document.body.classList.add('theme-light');
      document.querySelectorAll('.theme-btn').forEach(x => x.className = `theme-btn px-2.5 py-1 rounded-md font-semibold ${x.dataset.theme === state.theme ? 'bg-cyan-600 text-white' : 'text-slate-400'}`);
      const tickColor = state.theme === 'light' ? '#334155' : '#94a3b8';
      const legendColor = state.theme === 'light' ? '#0f172a' : '#cbd5e1';
      [zoneChart, history2yChart].forEach(ch => {
        ch.options.scales.x.ticks.color = tickColor;
        ch.options.scales.y.ticks.color = tickColor;
        ch.options.plugins.legend.labels.color = legendColor;
        ch.update();
      });
    });

    document.querySelectorAll('.lang-btn').forEach(b => b.onclick = () => {
      state.lang = b.dataset.lang;
      document.querySelectorAll('.lang-btn').forEach(x => x.className = `lang-btn px-2.5 py-1 rounded-md font-semibold ${x.dataset.lang === state.lang ? 'bg-cyan-600 text-white' : 'text-slate-400'}`);
      renderAll();
    });

    document.querySelectorAll('.layer-btn').forEach(b => b.onclick = () => {
      state.layer = b.dataset.layer;
      document.querySelectorAll('.layer-btn').forEach(x => x.className = `layer-btn px-2.5 py-1 rounded-lg font-semibold ${x.dataset.layer === state.layer ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-300'}`);
      renderAll();
    });

    document.querySelectorAll('.h2y-btn').forEach(b => b.onclick = () => {
      state.hMode = b.dataset.hmode;
      document.querySelectorAll('.h2y-btn').forEach(x => x.className = `h2y-btn px-3 py-1 rounded-lg font-semibold ${x.dataset.hmode === state.hMode ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-slate-300'}`);
      renderAll();
    });

    document.getElementById('rain-sim').onchange = e => { state.sim = e.target.value; renderAll(); };
    document.getElementById('btn-country').onclick = () => map.fitBounds(HONDURAS_BOUNDS);

    document.getElementById('btn-pdf').onclick = () => {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('ABYSS HONDURAS - INFORME NACIONAL DE RIESGO', 14, 18);
      doc.setFontSize(10);
      doc.text('Fecha de emision: 15 nov 2026 | Sentinel-1 (13 nov) | Sentinel-2 (14 nov)', 14, 25);
      let y = 36;
      ZONES.forEach(z => {
        const m = getZoneMetricsAtTime(z, 5);
        const r = computeCompositeRisk(m);
        const ndwiStr = m.ndwiRaw !== null ? m.ndwiRaw.toFixed(3) : `Nublado (${m.gee.ndwi_last.toFixed(3)})`;
        doc.text(`${z.name} (${z.dept}) - Riesgo: ${r}% | Def: ${m.def.toFixed(1)} mm | VH: ${m.vh.toFixed(2)} dB | NDWI: ${ndwiStr}`, 14, y);
        y += 8;
      });
      doc.addPage();
      doc.setFontSize(14);
      doc.text('PAGINA 2: HISTORIAL SATELITAL REAL DE 2 ANOS (NOV 2024 - NOV 2026)', 14, 18);
      doc.setFontSize(9.5);
      y = 30;
      ZONES.forEach(z => {
        const g = REAL_2Y_GEE[z.id];
        doc.text(`${z.name}: VH Prom ${g.vh_avg} dB (Min ${g.vh_min} / Max ${g.vh_max}) | Ultimo VH: ${g.vh_last} dB | NDWI Prom: ${g.ndwi_avg ?? 'N/D'} (${g.s1_count}m S1 / ${g.s2_count}m S2)`, 14, y);
        y += 8;
      });
      doc.save('Informe_Nacional_Abyss_Honduras.pdf');
    };

    renderAll();