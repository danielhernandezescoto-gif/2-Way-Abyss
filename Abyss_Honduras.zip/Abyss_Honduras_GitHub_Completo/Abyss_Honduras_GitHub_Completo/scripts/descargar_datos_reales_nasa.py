import asf_search as asf

# Búsqueda de escenas Sentinel-1 reales sobre Honduras (Valle de Sula)
wkt_honduras = "POLYGON((-88.25 15.30, -87.75 15.30, -87.75 15.60, -88.25 15.60, -88.25 15.30))"

results = asf.search(
    platform=[asf.PLATFORM.SENTINEL1],
    processingLevel=[asf.PRODUCT_TYPE.GRD_HD],
    intersectsWith=wkt_honduras,
    start="2026-09-15T00:00:00Z",
    end="2026-11-15T23:59:59Z"
)

print(f"Escenas reales encontradas sobre Honduras: {len(results)}")
for r in results[:5]:
    print(r.properties["sceneName"], "|", r.properties["startTime"])
