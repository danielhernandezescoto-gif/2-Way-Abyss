var zonas = ee.FeatureCollection([
  ee.Feature(ee.Geometry.Point([-88.02341, 15.43334]).buffer(500), {zona: 'Chamelecon_SPS'}),
  ee.Feature(ee.Geometry.Point([-87.94778, 15.47227]).buffer(500), {zona: 'Rivera_Hernandez_SPS'}),
  ee.Feature(ee.Geometry.Point([-88.16031, 15.41682]).buffer(500), {zona: 'Cofradia_SPS'}),
  ee.Feature(ee.Geometry.Point([-87.81450, 15.39300]).buffer(500), {zona: 'Rio_Ulua_El_Progreso'}),
  ee.Feature(ee.Geometry.Point([-87.20681, 14.08180]).buffer(500), {zona: 'Tegucigalpa'}),
  ee.Feature(ee.Geometry.Point([-87.18330, 13.30560]).buffer(500), {zona: 'Choluteca'}),
  ee.Feature(ee.Geometry.Point([-86.78220, 15.75970]).buffer(500), {zona: 'La_Ceiba'}),
  ee.Feature(ee.Geometry.Point([-86.00000, 15.68333]).buffer(500), {zona: 'Tocoa_Bajo_Aguan'}),
  ee.Feature(ee.Geometry.Point([-88.77560, 14.77388]).buffer(500), {zona: 'Santa_Rosa_de_Copan'})
]);

var inicio = ee.Date('2024-11-01');
var meses = ee.List.sequence(0, 24);

var tablaMensual = ee.FeatureCollection(meses.map(function(m) {
  var d1 = inicio.advance(m, 'month');
  var d2 = d1.advance(1, 'month');
  var mesStr = d1.format('YYYY-MM');

  var s1Mes = ee.ImageCollection('COPERNICUS/S1_GRD')
    .filterBounds(zonas).filterDate(d1, d2)
    .filter(ee.Filter.eq('instrumentMode', 'IW'))
    .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
    .select('VH').mean().rename('VH_dB');

  var s2Mes = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
    .filterBounds(zonas).filterDate(d1, d2)
    .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 35))
    .map(function(img) { return img.normalizedDifference(['B3', 'B8']).rename('NDWI'); })
    .mean();

  return ee.Image.cat([s1Mes, s2Mes]).reduceRegions({
    collection: zonas, reducer: ee.Reducer.mean(), scale: 20
  }).map(function(f) { return f.set('mes', mesStr); });
})).flatten();

Export.table.toDrive({
  collection: tablaMensual,
  description: 'Abyss_Historico_24Meses_Honduras',
  fileFormat: 'CSV',
  selectors: ['zona', 'mes', 'VH_dB', 'NDWI']
});
